#########

library(dplyr)
library(readr)
library(sf)
library(ggplot2)

# Chargement des données

data_service <- read_csv("data/anaspa_service.csv",col_names = T)
  
type <- read_csv("data/type_inf.csv", col_names = F)

# Vérification de la cohérence des données
plot(data_service$x,data_service$y)

# Calcul du poids moyen et poids moyen pondéré

# point moyen
meanx = mean(data_service$x)
meany = mean(data_service$y)
meanpoint = apply(data_service[,c("x","y")],MARGIN = 2, mean)

plot(data_service$x,data_service$y);points(meanx,meany,col='red')

# Point moyen pondere

# Pour violence
wmeanxviolences = sum(data_service$violence*data_service$x)/sum(data_service$violence)
wmeanyviolences = sum(data_service$violence*data_service$y)/sum(data_service$violence)

plot(data_service$x,data_service$y);points(wmeanxviolences,wmeanyviolences,col='red')

# Pour destruction
wmeanxdest = sum(data_service$destructio*data_service$x)/sum(data_service$destructio)
wmeanydest = sum(data_service$destructio*data_service$y)/sum(data_service$destructio)

plot(data_service$x,data_service$y);points(wmeanxdest,wmeanydest,col='red')

# Pour la somme des crimes et délits

wmeanxtot = sum(data_service$total_crim*data_service$x)/sum(data_service$total_crim)
wmeanytot = sum(data_service$total_crim*data_service$y)/sum(data_service$total_crim)

# Boucle pour chaque type d'infraction et la population
wmean = list()
for(inf in (type$X1)){
  show(inf)
  wmeanx = sum(data_service[,inf]*data_service$x)/sum(data_service[,inf])
  wmeany = sum(data_service[,inf]*data_service$y)/sum(data_service[,inf])
  wmean[[inf]] = c(wmeanx,wmeany)
}

data <- data_service[,c("violence","destructio","homicides","viols_crim","autres","stupefiant","falsificat","pop")]

wmean = apply(data,MARGIN = 2,FUN = function(inf){
  totalinf = sum(inf)
  wmeanx = sum(inf*data_service$x)/totalinf
  wmeany = sum(inf*data_service$y)/totalinf
  return(c(wmeanx,wmeany))
}
)

wmean1=data.frame(t(wmean))
wmean1$inf = type$X1

# Cartographie des régions et des points moyens


# Ajout de la couche régions
regions <- st_read(dsn='data/regions',layer='regions_2015_metropole_regions')
# Changement de système de coordonnées
regions = st_transform(regions,"EPSG:4326")

# plot point moyen uniquement
g1=ggplot(data=wmean1,aes(x=X1,y=X2,col=inf))
g1+geom_point()

# "carte" avec point moyen et regions
g=ggplot(data=regions)
g+geom_sf()+geom_point(data=wmean1,aes(x=X1,y=X2,col=inf),size=3.5)

# Meme carte "zoomee" avec ajout du point moyen non pondéré
g=ggplot(data=regions[regions$RégION%in%c("Ile-de-France","Bourgogne et Franche-Comté","Centre"),])
g+geom_sf()+geom_point(data=wmean1,aes(x=X1,y=X2,col=inf),size=3)+geom_point(data=data_service,aes(x=meanx, y=meany),size=3.5)+geom_point(data=data_service,aes(x=wmeanxtot, y=wmeanytot),size=3.5, color ='RED')
g+geom_sf()+geom_point(data=data_service,aes(x=meanx, y=meany,col="Point_moyen_geom"),size=3.5)+geom_point(data=data_service,aes(x=wmeanxtot, y=wmeanytot, col = 'Point_moyen_inf'),size=3.5)

############################################################################